======================================================
              Music Studio for Windows
======================================================

How to Run:
1. Double-click "MusicStudio.exe" or "MusicStudio.bat".
2. Music Studio will start and open your desktop player!

Features:
- Search, stream & download songs in high quality (320kbps).
- Automatic HD Album Art & ID3 Metadata embedding.
- Custom Playlist creation & Spotify/YouTube Music import.
- Works offline with all your downloaded music!

Requirements:
- Windows 10 or Windows 11 (64-bit).
- Python 3.8+ (If not installed, download from https://www.python.org/downloads/
  and check "Add Python to PATH").

To build a standalone 1-file .exe on Windows:
- Double-click "build_windows.bat".
======================================================
