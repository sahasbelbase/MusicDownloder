======================================================
              Music Studio for Windows
======================================================

How to Run:
1. Double-click "MusicStudio.exe" (or "MusicStudio.bat").
2. On first launch, Music Studio will automatically detect your
   Python environment and offer to install required dependencies
   (FastAPI, yt-dlp, pywebview, Pillow, and embedded FFmpeg provider).
3. Once completed, Music Studio will launch the desktop player window!

If You Encounter Startup Issues:
1. Run "MusicStudio.bat" directly — this opens a console window
   that displays complete startup logs and shows any errors.
2. Check your log file located at:
   %LOCALAPPDATA%\MusicStudio\Logs\desktop_app.log
3. To install all dependencies manually at any time:
   pip install -r requirements.txt

Features:
- Search, stream & download songs in high-fidelity 320kbps MP3.
- Automatic HD Album Art & ID3 Metadata embedding.
- Custom Playlist creation & Spotify/YouTube Music import.
- Works 100% offline with your local music library.
- Zero-configuration FFmpeg support via bundled imageio-ffmpeg.

Requirements:
- Windows 10 or Windows 11 (64-bit).
- Python 3.8+ (Available from https://www.python.org/downloads/
  Make sure to check "Add Python to PATH" during installation).

To Compile a Standalone Executable on Windows:
- Double-click "build_windows.bat".
======================================================
